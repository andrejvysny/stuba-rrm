#include <ros/ros.h>
#include <std_msgs/Float64.h>
#include <sensor_msgs/JointState.h>
#include "Robot.h"
#include <std_srvs/Trigger.h>
#include <thread>


void publisher(ros::NodeHandle* nodeHandle, Robot* robot);



bool moveAbsoluteCallback(std_srvs::Trigger::Request &req, std_srvs::Trigger::Response &res){
    res.success = true;
    res.message = "Hello robot";
    ROS_INFO("[SERVICE] move_absolute");
    return true;
}



int main(int argc, char **argv) {
    ros::init(argc, argv, "publisher");

    ROS_INFO("Started publisher");
    ros::NodeHandle n;

    Robot robot;


    std::thread publisher_thread;
    publisher_thread = std::thread(publisher,&n,&robot); // priradenie funkcie mimo triedy

   // publisher(&n, &robot);
//ros::ServiceServer service2_server = n.advertiseService("move_absolute", moveAbsoluteCallback);

    return 0;
}



void publisher(ros::NodeHandle* nodeHandle, Robot* robot){

    ros::Publisher js_publisher = nodeHandle->advertise<sensor_msgs::JointState>("joint_states", 1);

    ros::Rate loop_rate(10);
    while (ros::ok()) {
        sensor_msgs::JointState msg;
        msg.header.stamp = ros::Time::now();

        msg.name.resize(Robot::jointCount);
        msg.position.resize(Robot::jointCount);

        for (int i=0; i<Robot::jointCount; i++){
            msg.name.at(i) = "joint_" + std::to_string(i+1);
            msg.position.at(i) = robot->getJointValue(i+1);
            ROS_INFO("PUBLISH JOINT: %s = %f", msg.name.at(i).c_str(), msg.position.at(i));
        }

        js_publisher.publish(msg);
        loop_rate.sleep();
    }
}