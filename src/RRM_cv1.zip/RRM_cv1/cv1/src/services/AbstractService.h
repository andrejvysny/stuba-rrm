//
// Created by andrejvysny on 1.11.2023.
//

#ifndef SRC_ABSTRACTSERVICE_H
#define SRC_ABSTRACTSERVICE_H


#include <string>
#include <ros/node_handle.h>

class AbstractService {
public:
    AbstractService(std::string serviceName);
    void registerService(ros::NodeHandle* n);
protected:
    std::string serviceName;
    virtual bool callback() = 0;
};


#endif //SRC_ABSTRACTSERVICE_H
