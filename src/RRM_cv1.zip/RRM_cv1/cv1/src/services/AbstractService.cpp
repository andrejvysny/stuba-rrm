//
// Created by andrejvysny on 1.11.2023.
//

#include "AbstractService.h"

AbstractService::AbstractService(std::string serviceName) {
    this->serviceName = serviceName;
}
