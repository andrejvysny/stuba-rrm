//
// Created by andrejvysny on 1.11.2023.
//

#include <ros/node_handle.h>
#include "MoveAbsoluteService.h"


