
//
// Created by andrejvysny on 1.11.2023.
//

#ifndef SRC_MOVEABSOLUTESERVICE_H
#define SRC_MOVEABSOLUTESERVICE_H


#include "AbstractService.h"

class MoveAbsoluteService: public AbstractService {

public:
    MoveAbsoluteService();
};


#endif //SRC_MOVEABSOLUTESERVICE_H
