
#include <ros/ros.h>
#include <std_srvs/Trigger.h>
#include <rrm_msgs/Move.h>

bool func(rrm_msgs::Move::Request &req, rrm_msgs::Move::Response &res) {
    ROS_INFO("I receive positions a: %f b: %f", req.positions[0], req.positions[1]);
    res.success = true;
    res.message = "Done";
    return true;
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "hello_robot");
    ros::NodeHandle n;
    ROS_INFO("Hello robot");

    ros::ServiceServer service = n.advertiseService("move_absolute", func);

    ros::spin();

    return 0;
}