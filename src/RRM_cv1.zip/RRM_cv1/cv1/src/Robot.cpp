//
// Created by andrejvysny on 1.11.2023.
//

#include <exception>
#include <string>
#include "Robot.h"

void Robot::setJointValue(int jointNumber, float value) {
    if(!Robot::validateJointNumber(jointNumber)){
        throw std::exception();
    }
    this->joints[jointNumber-1] = value;
}

float Robot::getJointValue(int jointNumber) {
    if(!Robot::validateJointNumber(jointNumber)){
        throw std::exception();
    }
    return this->joints[jointNumber-1];
}

bool Robot::validateJointNumber(int jointNumber) {
    if(jointNumber-1 > Robot::jointCount || jointNumber < 1){ //TODO: check this condition - not sure is right
        return false;
    }
    return true;
}
