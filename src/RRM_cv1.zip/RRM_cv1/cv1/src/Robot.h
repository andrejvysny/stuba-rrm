//
// Created by andrejvysny on 1.11.2023.
//

#ifndef SRC_ROBOT_H
#define SRC_ROBOT_H


class Robot {

public:
    static const int jointCount = 6;
    float getJointValue(int jointNumber);
    void setJointValue(int jointNumber, float value);
private:
    float joints[Robot::jointCount] = {1.1,1.2,1.3,1.4,1.5,1.6};




    static bool validateJointNumber(int jointNumber);
};


#endif //SRC_ROBOT_H
